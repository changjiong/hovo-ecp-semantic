# domain-model

把固定版本的领域知识整理成不依赖数据库、软件或平台的领域模型。当前为 Hovo 0.5.0 候选包，领域模型合同为 3.0.0；随包带有仅用于输入核对的领域知识 4.0.0 Schema 快照。

PRODUCE 和 REVISE 显式选择 knowledge_basis：

- DRAFT 可基于未确认知识形成待审模型，但固定知识摘要，逐项映射开放上游问题，并禁止模型确认与正式交接。
- CONFIRMED 需要真实外部 ConfirmationRecord，该记录必须精确绑定知识版本、摘要和本次问题范围。

review_mode 与知识依据独立：它管理会话或线下模型评审，不会把知识 PENDING 范围变成已确认范围。REVIEW 只审查已有模型。

PRODUCE 与 REVISE 交付 output.json、面向业务责任人的 review.md 和审计用 coverage.md。问题覆盖只可标为 MODELED、PARTIAL 或 DEFERRED；案例只可标为 EXPLAINED 或 BLOCKED。PARTIAL、DEFERRED 和 BLOCKED 保留问题与原因，不能宣称 PASS。

在本包目录运行以下本地合同检查：

    python3 scripts/validate_contract.py --check-schemas
    python3 scripts/validate_contract.py validate input /path/to/project/domain-model/input.json --project-root /path/to/project
    python3 scripts/validate_contract.py validate output /path/to/project/domain-model/output.json --project-root /path/to/project

本地检查核对结构、真实摘要、引用和覆盖约束；不证明来源真实性、业务正确性、人工确认、安装结果或运行状态。
