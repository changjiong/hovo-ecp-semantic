---
name: domain-model
description: 将固定版本的领域知识转成独立于数据库和平台的领域模型，或审查、修订已有模型。区分待审草案与已确认依据，定义概念、属性、关系、时间、状态、证据和判断机理；不编制数据映射或平台资产。
metadata:
  author: Hovo
  version: "0.5.0"
---

# 领域模型构建

回答“业务世界由什么组成、如何变化、依据什么作出判断”。交付可由业务责任人审阅、由后续阶段追溯的领域模型，不把表、字段、SQL、平台算子或运行配置写成业务定义。

## 入口与合同

读取[输入合同](contracts/input.schema.json)、[输出合同](contracts/output.schema.json)、[合同说明](contracts/README.md)和[验收清单](references/acceptance.md)。本包随附领域知识 4.0.0 的输出与公共 Schema 快照，只用它核对上游成果；不读取或调用另一个技能目录。

- PRODUCE 与 REVISE 必须选择 knowledge_basis，并独立选择 review_mode。review_mode 只说明本轮模型评审如何进行，不能替代上游知识确认。
- DRAFT 固定知识 ArtifactRef 的版本、路径和摘要。将每个开放上游问题登记到 upstream_issue_bindings，映射为开放的 MODEL_GAP 和影响范围；问题覆盖写 MODELED、PARTIAL 或 DEFERRED，案例写 EXPLAINED 或 BLOCKED。模型 confirmation 必须为 PENDING，不能作正式交接或确认。
- CONFIRMED 必须提供真实外部 ConfirmationRecord，精确绑定知识文件字节、责任人答复和本次 question_scope_ids。输出 evidence 也要保留该记录的绑定，便于独立核验。
- REVIEW 只审查 subjects 中的既有模型，列出限制和 issues；不补造知识基线、确认记录或新模型。

## 建模与覆盖

1. 固定问题范围、知识依据、既有模型与变更请求。REVISE 先列受影响概念、关系、机理、问题和案例，产生新版本并重新评审受影响范围。
2. 定义概念、角色、属性、关系、身份、时间、状态、事件、度量、证据和未知语义。每项写依据、正例和反例；业务属性经“更换软件系统后是否仍成立”检查。
3. 每项判断机理列读取事实、引用规则、条件、业务操作、输出和缺证行为。不得编造平台 DSL、数据表或运行结论。
4. question_coverage 逐项覆盖范围内知识问题。PARTIAL 与 DEFERRED 必须关联开放 MODEL_GAP 并说明原因；有开放缺口不得标记 MODELED。
5. case_explanations 逐项解释范围内案例，逐字保留知识的 expected 与 forbidden。无法解释时写 BLOCKED 并关联其问题的开放模型缺口，不能用通过或 PASS 掩盖。
6. PRODUCE 与 REVISE 同时交付 review.md 和 coverage.md：前者给业务人员阅读，后者是问题、案例、上游问题和模型落点的审计台账。两份文件须登记真实摘要；REVIEW 只交付审查意见。

## 评审与完成边界

按[交互式评审](references/interactive-review.md)处理会话和线下反馈。原始反馈绑定版本和范围；修订后，受影响范围的旧确认只保留为历史并重新评审。DRAFT 可以完成本轮模型草案，不等于业务认可、正式需求、发布或运行。

结构和引用检查只能证明合同形状及有限一致性。它不证明来源真实、业务逻辑正确、责任人身份、平台编译、发布、运行或任何受益所有人结论。

创建和修订必须明确非空问题范围，且属于知识问题目录与知识声明范围；声明范围本身不是批准。DRAFT和CONFIRMED都逐项处置上游开放事项，范围外事项可注明不适用及原因，不能遗漏已影响本次问题的缺口。每题覆盖表须列全实际影响该题的开放模型缺口。知识的正式确认记录同时绑定知识output、review.md、coverage.md及真实答复；已REJECTED或STALE的基线不能借旧批准绕过。
