# 平台无关领域模型合同 3.0.0

本包的公共对象、模型输入输出 Schema、领域知识 4.0.0 输出 Schema 和其公共 Schema 都随包提供。领域知识快照只用于核对输入，不要求安装或调用 domain-knowledge，也不接受 2.0.0 或其他旧知识合同作为 3.0.0 的上游资产。

## 输入与依据状态

PRODUCE 和 REVISE 继续使用 request_id、mode、scope、knowledge、question_scope_ids 与 review_mode，并新增必选 knowledge_basis。REVIEW 只需要 subjects。

- DRAFT：knowledge 必须是符合 4.0.0 的非 REVIEW 知识成果，且 ArtifactRef 的路径、版本和 SHA-256 摘要可读取并匹配。不得附带 knowledge_confirmation，也不得把知识 confirmation 的 PENDING scope 视为已确认范围。
- CONFIRMED：除上述精确知识引用外，必须提供 knowledge_confirmation。它是指向外部 ConfirmationRecord 的 EvidenceRef；记录必须 APPROVED、同时绑定该知识 ArtifactRef 的完整身份和字节摘要，并覆盖 question_scope_ids。
- review_mode 的 IN_SESSION 或 DEFERRED 仅描述模型评审方式。它不改变 knowledge_basis，也不产生确认。

## 输出与审计

所有非 REVIEW 输出的 content 保留 concepts、attributes、relationships、semantics、mechanisms、question_coverage、case_explanations、decisions、knowledge_ref 和 question_scope_ids，并新增：

- knowledge_basis：DRAFT 或 CONFIRMED，与输入选择一致。
- upstream_issue_bindings：每项列 knowledge_issue_id、对应开放 MODEL_GAP、处理方式和理由。DRAFT 必须逐项覆盖上游所有 OPEN issue；通用语义未完整也必须登记为模型限制。
- question_coverage.status：MODELED、PARTIAL 或 DEFERRED，并写原因。PARTIAL 和 DEFERRED 关联开放 MODEL_GAP；存在该问题的开放缺口时不得写 MODELED。
- case_explanations.status：EXPLAINED 或 BLOCKED。BLOCKED 保留原案例 expected 和 forbidden，并由关联问题的 PARTIAL 或 DEFERRED 说明。

knowledge_ref 也必须出现在 input_refs。CONFIRMED 输出的 evidence 中必须有一个真实外部 ConfirmationRecord 绑定知识文件和模型范围，供输出单独检查。DRAFT 输出的 confirmation.status 必须为 PENDING；因此没有正式下游交接或业务确认。

PRODUCE 和 REVISE 必须登记 review.md 与 coverage.md，且都使用当前 content_version 和真实摘要。review.md 面向业务责任人呈现范围、模型、判断、案例与待确认事项；coverage.md 是问题、案例、上游 issue、模型 issue 和引用的审计表。REVIEW 只登记审查意见，不生成待审模型。

## 线下与会话评审

原始反馈保持为独立 ArtifactRef，写明固定的版本、摘要、问题范围、答复者、角色、时间和逐项意见。修订必须新建版本，列受影响问题、案例、概念和机制；受影响的旧确认是历史证据，不覆盖新文件。业务人员审阅 review.md 并答复业务事项，不编辑 JSON 或内部 ID。

## 检查边界

本地校验检查 JSON Schema、字节摘要、引用、范围、问题和案例覆盖、确认记录的结构与精确绑定。它不证明来源真实性、正文语义正确、确认人身份、业务验收、平台发布、运行或实际控制人结论。

创建和修订必须明确非空问题范围，且属于知识问题目录与知识声明范围；声明范围本身不是批准。DRAFT和CONFIRMED都逐项处置上游开放事项，范围外事项可注明不适用及原因，不能遗漏已影响本次问题的缺口。每题覆盖表须列全实际影响该题的开放模型缺口。知识的正式确认记录同时绑定知识output、review.md、coverage.md及真实答复；已REJECTED或STALE的基线不能借旧批准绕过。
