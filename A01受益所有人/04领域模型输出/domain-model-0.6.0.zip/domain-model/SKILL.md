---
name: domain-model
description: 将固定版本的领域知识转为平台无关的领域模型 DSL（model.yaml），或审查、修订已有模型；定义实体、角色、身份、属性类型、关系基数、时间区间、规则条件和状态迁移，生成业务审阅文档。用于领域建模及模型修订；不提取原始制度知识，不设计数据库或 ECP 平台资产，不发布运行。
metadata:
  author: Hovo
  version: "0.6.0"
---

# 领域模型 DSL

核心交付是可解析、可作有限语义校验与示例求值的 `model.yaml`。模型须独立于数据库和执行平台。描述、解释和 Mermaid 图服务于理解；判断条件必须使用本语言的结构化表达式。

## 入口

先读[合同](contracts/README.md)及[DSL 规范](references/domain-dsl.md)，需要具体建模方法时按[索引](references/handbook-index.md)加载。随包知识 4.0.0 Schema 只用于上游准入，不借用其他技能的资源。

- PRODUCE：固定知识 ArtifactRef、非空问题范围、knowledge_basis 和 review_mode。
- REVISE：另固定旧版 subjects 与 change_request；新版本重新生成受影响产物，旧确认不自动继承。
- REVIEW：只审查指定既有成果，交付审查意见和问题；不擅自重写 DSL。
- DRAFT：允许从未确认知识建模，逐项承接所有上游开放事项，模型确认保持 PENDING。
- CONFIRMED：知识必须有真实外部 ConfirmationRecord，绑定知识 output/review/coverage 的精确字节及本次范围。该准入不等于模型已确认。
- review_mode=IN_SESSION 时逐项对话收集意见；DEFERRED 交付可转交的评审包。评审方式与知识依据互相独立。

## 建模步骤

1. 核对输入合同、知识版本和范围。不要先缩成几个方便展示的问题；本次范围每题必须有覆盖记录，关联案例每例必须有解释。
2. 列类型与身份。区分实体、角色、事实、事件、观察、证据、决策、任务；属性声明类型与基数，关系是有目标类型的 Ref 字段，角色声明 bearer_field。每种类型给正反例和依据。
3. 明确时间区间、有效起止与终止未知；区分观测和业务生效时间。需要多个时间含义时分别建字段与 temporal 声明，不混用空值。
4. 将判断写成有类型的输入、结果和 expression；状态变化写成 from/event/guard/to。缺失值传播 UNKNOWN；只有 guard 为真才能迁移。不得用说明文字或任意代码充当规则。
5. 超出语言能力或待责任人裁定的判断登记 judgment、所需证据、责任角色和开放 MODEL_GAP。仅列人工判断不能宣称 MODELED。不要为了让校验通过删掉困难规则。
6. 对照固定知识逐题、逐例检查。保留 expected/forbidden 原文；全部上游 OPEN 事项进入 upstream_issue_bindings。范围外事项有理由才能标不适用；部分完成写 PARTIAL/DEFERRED。
7. 用 `domain_dsl.py validate` 做静态检查；用实际案例输入做 evaluate/transition，保存输入及实测结果。示例求值不等于上游事实已获证实。
8. 用 `deliver_model.py` 从同一 DSL 生成 review.md、coverage.md、output.json，并执行交接检查。不单独编辑生成文档；改 DSL 后产生新内容版本。生成器拒绝覆盖既有交付文件。
9. 按[交互评审](references/interactive-review.md)收集答复、落实修订、重跑受影响验证；按[验收清单](references/acceptance.md)分别报告结构、示例行为、业务评审与确认。

## 交付与边界

交付 `model.yaml`、业务审閱 `review.md`、审计 `coverage.md`、版本交接 `output.json` 和实际校验记录。完整条款覆盖台账保留在 coverage.md，业务说明不堆入条款矩阵。

语言 1.0.0 的运算符是封闭集合。没有任意脚本、数据库访问或 ECP 执行；当前日期区间运算只处理 Date 精度。多路径图计算、循环控制、复杂集合、跨规则调用等尚未提供，必须显式留缺口，不能写伪 DSL。

输出合同 4.0.0 不接受旧版自然语言机制合同 3.0.0；不自动迁移旧模型。平台转译技能须显式支持本 DSL 后方可正式交接；本轮不宣称 ECP 已能编译本模型。

本地 PASS 只证明所列检查成立，不证明制度解释、证据真实性、业务批准、平台发布或运行。当前包是 candidate；完整证据及缺项见[交付报告](reports/creation-handoff.md)。
