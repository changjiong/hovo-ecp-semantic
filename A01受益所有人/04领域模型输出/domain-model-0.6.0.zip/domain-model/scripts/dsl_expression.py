"""Internal module: restricted expression typing and evaluation for the domain-model DSL.

The module accepts only the DSL expression tree.  It never evaluates Python,
imports user code, or follows paths supplied by the model.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
import json
from typing import Any, Mapping


UNKNOWN = None
SCALAR_TYPES = frozenset({"Text", "Boolean", "Integer", "Decimal", "Date", "DateTime"})
FIELD_TYPES = frozenset((*SCALAR_TYPES, "Enum", "Ref", "IntervalSet"))


class DSLExpressionError(ValueError):
    """A deterministic, user-facing DSL expression error."""

    def __init__(self, code: str, location: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.location = location
        self.message = message


@dataclass(frozen=True)
class ValueSpec:
    data_type: str
    target: str | None = None
    values: tuple[str, ...] = ()
    max_items: int | None = 1


def _fail(code: str, location: str, message: str) -> None:
    raise DSLExpressionError(code, location, message)


def _keys(value: Any, allowed: set[str], location: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        _fail("EXPR_OBJECT_REQUIRED", location, "表达式必须是对象")
    actual = set(value)
    if actual != allowed:
        _fail("EXPR_SHAPE_INVALID", location, f"表达式字段必须且只能是 {sorted(allowed)}")
    return value


def declaration_spec(declaration: Mapping[str, Any], location: str) -> ValueSpec:
    if not isinstance(declaration, dict):
        _fail("DECLARATION_INVALID", location, "输入或输出声明必须是对象")
    data_type = declaration.get("type")
    if data_type not in FIELD_TYPES:
        _fail("TYPE_INVALID", location + "/type", "不支持的 DSL 类型")
    target = declaration.get("target")
    values = declaration.get("values")
    if data_type == "Ref":
        if not isinstance(target, str) or not target:
            _fail("REF_TARGET_REQUIRED", location + "/target", "Ref 必须声明 target")
    elif target is not None:
        _fail("TYPE_TARGET_INVALID", location + "/target", "只有 Ref 可以声明 target")
    if data_type == "Enum":
        if not isinstance(values, list) or not values or not all(isinstance(item, str) and item for item in values):
            _fail("ENUM_VALUES_REQUIRED", location + "/values", "Enum 必须声明非空文本 values")
        if len(values) != len(set(values)):
            _fail("ENUM_VALUES_DUPLICATE", location + "/values", "Enum values 不能重复")
    elif values is not None:
        _fail("TYPE_VALUES_INVALID", location + "/values", "只有 Enum 可以声明 values")
    return ValueSpec(data_type=data_type, target=target, values=tuple(values or ()))


def field_spec(field: Mapping[str, Any], location: str) -> ValueSpec:
    spec = declaration_spec(field, location)
    cardinality = field.get("cardinality")
    if not isinstance(cardinality, dict):
        _fail("CARDINALITY_REQUIRED", location + "/cardinality", "字段必须声明 cardinality")
    maximum = cardinality.get("max")
    if maximum is not None and (not isinstance(maximum, int) or isinstance(maximum, bool) or maximum < 0):
        _fail("CARDINALITY_INVALID", location + "/cardinality/max", "max 必须是非负整数或 null")
    return ValueSpec(spec.data_type, spec.target, spec.values, maximum)


def _decimal(value: Any, location: str) -> Decimal:
    if isinstance(value, bool):
        _fail("DECIMAL_INVALID", location, "Boolean 不能作为 Decimal")
    if isinstance(value, Decimal):
        parsed = value
    elif isinstance(value, (str, int, float)):
        try:
            parsed = Decimal(str(value))
        except InvalidOperation:
            _fail("DECIMAL_INVALID", location, "不是有效十进制数")
    else:
        _fail("DECIMAL_INVALID", location, "Decimal 值类型错误")
    if not parsed.is_finite():
        _fail("DECIMAL_NONFINITE", location, "Decimal 不得为 NaN 或无穷")
    return parsed


def _date(value: Any, location: str) -> str:
    if not isinstance(value, str):
        _fail("DATE_INVALID", location, "Date 必须是 ISO 日期字符串")
    try:
        date.fromisoformat(value)
    except ValueError:
        _fail("DATE_INVALID", location, "Date 必须是 ISO 日期字符串")
    if date.fromisoformat(value).isoformat() != value:
        _fail("DATE_INVALID", location, "Date 必须为 YYYY-MM-DD")
    return value


def _datetime(value: Any, location: str) -> str:
    if not isinstance(value, str) or "T" not in value:
        _fail("DATETIME_INVALID", location, "DateTime 必须是 ISO 日期时间字符串")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        _fail("DATETIME_INVALID", location, "DateTime 必须是 ISO 日期时间字符串")
    if parsed.tzinfo is None:
        _fail("DATETIME_INVALID", location, "DateTime 必须带时区")
    return parsed.astimezone(timezone.utc).isoformat(timespec="microseconds")


def _single_value(value: Any, spec: ValueSpec, types: Mapping[str, Mapping[str, Any]], location: str, depth: int) -> Any:
    if value is UNKNOWN:
        return UNKNOWN
    if spec.data_type == "Text":
        if not isinstance(value, str):
            _fail("RUNTIME_TYPE_INVALID", location, "期望 Text")
        return value
    if spec.data_type == "Boolean":
        if not isinstance(value, bool):
            _fail("RUNTIME_TYPE_INVALID", location, "期望 Boolean")
        return value
    if spec.data_type == "Integer":
        if not isinstance(value, int) or isinstance(value, bool):
            _fail("RUNTIME_TYPE_INVALID", location, "期望 Integer")
        return value
    if spec.data_type == "Decimal":
        return _decimal(value, location)
    if spec.data_type == "Date":
        return _date(value, location)
    if spec.data_type == "DateTime":
        return _datetime(value, location)
    if spec.data_type == "Enum":
        if not isinstance(value, str) or value not in spec.values:
            _fail("RUNTIME_ENUM_INVALID", location, "枚举值不在声明范围内")
        return value
    if spec.data_type == "Ref":
        return validate_ref(value, spec, types, location, depth + 1)
    if spec.data_type == "IntervalSet":
        return validate_interval_set(value, location)
    _fail("RUNTIME_TYPE_INVALID", location, "未知 DSL 类型")


def validate_field_value(value: Any, spec: ValueSpec, types: Mapping[str, Mapping[str, Any]], location: str, minimum: int = 0, depth: int = 0) -> Any:
    """Validate a value according to field cardinality and return canonical runtime values."""
    if depth > 16:
        _fail("REF_DEPTH_EXCEEDED", location, "Ref 嵌套超过安全深度")
    multi = spec.max_items is None or spec.max_items > 1
    if multi:
        if value is UNKNOWN:
            if minimum:
                _fail("RUNTIME_REQUIRED_VALUE_MISSING", location, "必填多值字段不能为未知")
            return UNKNOWN
        if not isinstance(value, list):
            _fail("RUNTIME_CARDINALITY_INVALID", location, "多值字段必须是数组")
        if len(value) < minimum or (spec.max_items is not None and len(value) > spec.max_items):
            _fail("RUNTIME_CARDINALITY_INVALID", location, "字段值数量不符合 cardinality")
        return [_single_value(item, spec, types, f"{location}/{index}", depth) for index, item in enumerate(value)]
    if isinstance(value, list) and spec.data_type != "IntervalSet":
        _fail("RUNTIME_CARDINALITY_INVALID", location, "单值字段不能使用数组")
    if value is UNKNOWN and minimum:
        _fail("RUNTIME_REQUIRED_VALUE_MISSING", location, "必填字段不能为未知")
    return _single_value(value, spec, types, location, depth)


def validate_ref(value: Any, spec: ValueSpec, types: Mapping[str, Mapping[str, Any]], location: str, depth: int = 0) -> dict[str, Any] | None:
    if value is UNKNOWN:
        return UNKNOWN
    if not isinstance(value, dict):
        _fail("RUNTIME_REF_INVALID", location, "Ref 必须是对象或 unknown")
    target = spec.target
    if target not in types:
        _fail("RUNTIME_REF_TARGET_INVALID", location, "Ref target 不存在")
    type_def = types[target]
    fields = {field["name"]: field for field in type_def.get("fields", [])}
    unknown = set(value) - set(fields)
    if unknown:
        _fail("RUNTIME_REF_UNKNOWN_FIELD", location, f"Ref 含未声明字段: {sorted(unknown)}")
    canonical: dict[str, Any] = {}
    for name, field in fields.items():
        if name not in value:
            if field["cardinality"]["min"] > 0:
                _fail("RUNTIME_REQUIRED_VALUE_MISSING", location + "/" + name, "缺少必需字段")
            continue
        cardinality = field["cardinality"]
        canonical[name] = validate_field_value(
            value[name],
            field_spec(field, f"{location}/{name}"),
            types,
            f"{location}/{name}",
            minimum=cardinality["min"],
            depth=depth,
        )
    for identity_name in type_def.get("identity", []):
        if identity_name not in canonical or canonical[identity_name] is UNKNOWN:
            _fail("RUNTIME_REF_IDENTITY_MISSING", location, f"Ref 缺少身份字段: {identity_name}")
    return canonical


def validate_interval_set(value: Any, location: str) -> list[dict[str, Any]] | None:
    if value is UNKNOWN:
        return UNKNOWN
    if not isinstance(value, list):
        _fail("INTERVAL_SET_INVALID", location, "IntervalSet 必须是区间数组或 unknown")
    result: list[dict[str, Any]] = []
    for index, interval in enumerate(value):
        interval_location = f"{location}/{index}"
        if not isinstance(interval, dict) or set(interval) != {"start", "end", "end_status"}:
            _fail("INTERVAL_SHAPE_INVALID", interval_location, "区间必须且只能有 start、end、end_status")
        start = _date(interval["start"], interval_location + "/start")
        end_status = interval["end_status"]
        if end_status not in {"OPEN", "KNOWN", "UNKNOWN"}:
            _fail("INTERVAL_STATUS_INVALID", interval_location + "/end_status", "end_status 必须为 OPEN、KNOWN 或 UNKNOWN")
        end = interval["end"]
        if end_status == "OPEN":
            if end is not None:
                _fail("INTERVAL_OPEN_END_INVALID", interval_location + "/end", "OPEN 区间的 end 必须为 null")
        elif end_status == "KNOWN":
            end = _date(end, interval_location + "/end")
            if date.fromisoformat(end) <= date.fromisoformat(start):
                _fail("INTERVAL_ORDER_INVALID", interval_location, "KNOWN 区间必须满足 end 大于 start")
        elif end is not None:
            _date(end, interval_location + "/end")
        result.append({"start": start, "end": end, "end_status": end_status})
    return result


def _compatible(left: ValueSpec, right: ValueSpec) -> bool:
    if left.data_type == right.data_type:
        if left.data_type == "Ref":
            return left.target == right.target
        if left.data_type == "Enum":
            return left.values == right.values
        return True
    return {left.data_type, right.data_type} == {"Integer", "Decimal"}


def _numeric(spec: ValueSpec) -> bool:
    return spec.data_type in {"Integer", "Decimal"}


def _single(spec: ValueSpec, location: str) -> None:
    if spec.max_items is None or spec.max_items > 1:
        _fail("MULTI_VALUE_EXPRESSION_FORBIDDEN", location, "多值字段不能直接作为单值表达式")


def infer_expression(expr: Any, environment: Mapping[str, ValueSpec], types: Mapping[str, Mapping[str, Any]], location: str = "/expression") -> ValueSpec:
    """Infer expression output type and reject unsupported or ambiguous forms."""
    if not isinstance(expr, dict) or (set(expr) != {"op", "args"} and len(expr) != 1):
        _fail("EXPR_SHAPE_INVALID", location, "表达式必须恰有一个节点")
    key = "op" if "op" in expr else next(iter(expr))
    payload = expr[key]
    if key == "input":
        if not isinstance(payload, str) or payload not in environment:
            _fail("EXPR_INPUT_UNKNOWN", location + "/input", "表达式引用了未声明输入")
        spec = environment[payload]
        _single(spec, location)
        return spec
    if key == "literal":
        literal = _keys(payload, {"type", "value"}, location + "/literal")
        data_type = literal["type"]
        if data_type not in SCALAR_TYPES:
            _fail("LITERAL_TYPE_INVALID", location + "/literal/type", "literal 只允许标量类型")
        spec = ValueSpec(data_type)
        _single_value(literal["value"], spec, types, location + "/literal/value", 0)
        return spec
    if key == "field":
        field = _keys(payload, {"of", "name"}, location + "/field")
        of_spec = infer_expression(field["of"], environment, types, location + "/field/of")
        if of_spec.data_type != "Ref" or not of_spec.target:
            _fail("FIELD_ACCESS_INVALID", location + "/field/of", "field.of 必须是单值 Ref")
        _single(of_spec, location + "/field/of")
        if not isinstance(field["name"], str):
            _fail("FIELD_NAME_INVALID", location + "/field/name", "field.name 必须是文本")
        target = types.get(of_spec.target)
        fields = {item["name"]: item for item in (target or {}).get("fields", [])}
        if field["name"] not in fields:
            _fail("FIELD_UNKNOWN", location + "/field/name", "field.name 未在 Ref target 中声明")
        output = field_spec(fields[field["name"]], location + "/field/name")
        _single(output, location + "/field/name")
        return output
    if key != "op":
        _fail("EXPR_OPERATOR_UNKNOWN", location, "未知表达式节点")
    node = _keys(expr, {"op", "args"}, location)
    operator = node["op"]
    args = node["args"]
    if not isinstance(operator, str) or not isinstance(args, list):
        _fail("OPERATOR_SHAPE_INVALID", location + "/op", "op 节点必须含 operator 和 args")
    specs = [infer_expression(arg, environment, types, f"{location}/args/{index}") for index, arg in enumerate(args)]
    if operator in {"and", "or"}:
        if len(specs) < 2 or any(spec.data_type != "Boolean" for spec in specs):
            _fail("OPERATOR_TYPE_INVALID", location, f"{operator} 需要至少两个 Boolean")
        return ValueSpec("Boolean")
    if operator == "not":
        if len(specs) != 1 or specs[0].data_type != "Boolean":
            _fail("OPERATOR_TYPE_INVALID", location, "not 需要一个 Boolean")
        return ValueSpec("Boolean")
    if operator in {"eq", "ne"}:
        if len(specs) != 2 or not _compatible(specs[0], specs[1]) or any(s.data_type in {"Ref", "IntervalSet"} for s in specs):
            _fail("OPERATOR_TYPE_INVALID", location, f"{operator} 需要两个兼容的单值")
        return ValueSpec("Boolean")
    if operator in {"lt", "lte", "gt", "gte"}:
        if len(specs) != 2:
            _fail("OPERATOR_TYPE_INVALID", location, f"{operator} 需要两个值")
        ordered = (_numeric(specs[0]) and _numeric(specs[1])) or (
            specs[0].data_type == specs[1].data_type and specs[0].data_type in {"Date", "DateTime"}
        )
        if not ordered:
            _fail("OPERATOR_TYPE_INVALID", location, f"{operator} 只支持数字、同类型 Date 或同类型 DateTime")
        return ValueSpec("Boolean")
    if operator in {"add", "multiply"}:
        if len(specs) < 2 or any(not _numeric(spec) for spec in specs):
            _fail("OPERATOR_TYPE_INVALID", location, f"{operator} 需要至少两个数字")
        return ValueSpec("Decimal")
    if operator == "current_interval_start":
        expected = ("IntervalSet", "Date", "Boolean", "Boolean")
        if len(specs) != 4 or tuple(spec.data_type for spec in specs) != expected:
            _fail("OPERATOR_TYPE_INVALID", location, "current_interval_start 参数必须为 IntervalSet、Date、Boolean、Boolean")
        return ValueSpec("Date")
    _fail("OPERATOR_UNKNOWN", location + "/op", "不支持的 operator")


def _eval(expr: dict[str, Any], environment: Mapping[str, Any], specs: Mapping[str, ValueSpec], types: Mapping[str, Mapping[str, Any]], location: str) -> Any:
    key = "op" if "op" in expr else next(iter(expr))
    payload = expr[key]
    if key == "input":
        return environment.get(payload, UNKNOWN)
    if key == "literal":
        return _single_value(payload["value"], ValueSpec(payload["type"]), types, location + "/literal/value", 0)
    if key == "field":
        ref = _eval(payload["of"], environment, specs, types, location + "/field/of")
        if ref is UNKNOWN:
            return UNKNOWN
        return ref.get(payload["name"], UNKNOWN)
    operator = expr["op"]
    args = [_eval(arg, environment, specs, types, f"{location}/args/{index}") for index, arg in enumerate(expr["args"])]
    if operator == "and":
        if any(value is False for value in args):
            return False
        return UNKNOWN if any(value is UNKNOWN for value in args) else True
    if operator == "or":
        if any(value is True for value in args):
            return True
        return UNKNOWN if any(value is UNKNOWN for value in args) else False
    if operator == "not":
        return UNKNOWN if args[0] is UNKNOWN else not args[0]
    if operator in {"eq", "ne", "lt", "lte", "gt", "gte"}:
        if any(value is UNKNOWN for value in args):
            return UNKNOWN
        left, right = args
        if operator == "eq":
            return left == right
        if operator == "ne":
            return left != right
        if operator == "lt":
            return left < right
        if operator == "lte":
            return left <= right
        if operator == "gt":
            return left > right
        return left >= right
    if operator in {"add", "multiply"}:
        if any(value is UNKNOWN for value in args):
            return UNKNOWN
        if operator == "add":
            total = Decimal("0")
            for value in args:
                total += Decimal(value)
            return total
        total = Decimal("1")
        for value in args:
            total *= Decimal(value)
        return total
    if operator == "current_interval_start":
        return current_interval_start(args[0], args[1], args[2], args[3], location)
    _fail("OPERATOR_UNKNOWN", location, "不支持的 operator")


def evaluate_expression(expr: Any, environment: Mapping[str, Any], specs: Mapping[str, ValueSpec], types: Mapping[str, Mapping[str, Any]], location: str = "/expression") -> Any:
    infer_expression(expr, specs, types, location)
    canonical_environment: dict[str, Any] = {}
    unknown = set(environment) - set(specs)
    if unknown:
        _fail("RUNTIME_INPUT_UNKNOWN", location, f"输入含未声明变量: {sorted(unknown)}")
    for name, spec in specs.items():
        canonical_environment[name] = validate_field_value(
            environment.get(name, UNKNOWN), spec, types, f"{location}/inputs/{name}"
        )
    return _eval(expr, canonical_environment, specs, types, location)


def current_interval_start(intervals: Any, as_of: Any, history_complete: Any, continuity_verified: Any, location: str) -> str | None:
    """Return the start of the current continuous interval or explicit UNKNOWN."""
    if intervals is UNKNOWN or as_of is UNKNOWN or history_complete is UNKNOWN or continuity_verified is UNKNOWN:
        return UNKNOWN
    if history_complete is not True or continuity_verified is not True:
        return UNKNOWN
    if not intervals:
        return UNKNOWN
    as_of_value = date.fromisoformat(as_of)
    normalized = validate_interval_set(intervals, location + "/intervals")
    if normalized is UNKNOWN or any(item["end_status"] == "UNKNOWN" for item in normalized):
        return UNKNOWN
    ordered = sorted(normalized, key=lambda item: item["start"])
    merged: list[dict[str, Any]] = []
    for interval in ordered:
        item = dict(interval)
        if not merged:
            merged.append(item)
            continue
        previous = merged[-1]
        previous_end = previous["end"]
        if previous_end is None or date.fromisoformat(item["start"]) <= date.fromisoformat(previous_end):
            if previous_end is None or item["end"] is None:
                previous["end"] = None
                previous["end_status"] = "OPEN"
            elif date.fromisoformat(item["end"]) > date.fromisoformat(previous_end):
                previous["end"] = item["end"]
        else:
            merged.append(item)
    for interval in merged:
        start = date.fromisoformat(interval["start"])
        end = interval["end"]
        if start <= as_of_value and (end is None or as_of_value < date.fromisoformat(end)):
            return interval["start"]
    return UNKNOWN


def render_expression(expr: Any) -> str:
    """Render a compact, deterministic business-readable expression."""
    if not isinstance(expr, dict) or (set(expr) != {"op", "args"} and len(expr) != 1):
        return "无效表达式"
    key = "op" if "op" in expr else next(iter(expr))
    payload = expr[key]
    if key == "input":
        return str(payload)
    if key == "literal":
        return json.dumps(payload.get("value"), ensure_ascii=False, default=str)
    if key == "field":
        return f"{render_expression(payload.get('of'))}.{payload.get('name')}"
    if key != "op":
        return "无效表达式"
    operator = expr.get("op")
    args = [render_expression(item) for item in expr.get("args", [])]
    symbols = {"and": " 且 ", "or": " 或 ", "eq": " = ", "ne": " ≠ ", "lt": " < ", "lte": " ≤ ", "gt": " > ", "gte": " ≥ ", "add": " + ", "multiply": " × "}
    if operator in symbols:
        return "(" + symbols[operator].join(args) + ")"
    if operator == "not":
        return "非(" + (args[0] if args else "？") + ")"
    if operator == "current_interval_start":
        return "当前连续区间起点(" + "，".join(args) + ")"
    return str(operator) + "(" + "，".join(args) + ")"
