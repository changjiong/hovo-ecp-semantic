# Domain DSL 1.0.0

本地、声明式、基于 YAML 的领域语言；规范结构由 `contracts/domain-model.dsl.schema.json` 约束，跨引用与表达式类型由 `scripts/domain_dsl.py` 检查。无需数据库或 ECP。所有对象拒绝未知字段；safe loader 拒绝重复键、别名、合并键、自定义对象标签及非 JSON 数据。日期使用带引号的 ISO 字符串。Date 严格为 YYYY-MM-DD；DateTime 必须带时区，求值时统一 UTC。

## 根结构

`dsl_version, artifact_id, content_version, name, knowledge_ref, knowledge_basis, question_scope_ids, types, temporal, rules, state_machines, judgments, question_coverage, case_explanations, upstream_issue_bindings, issues` 必须完整提供；不适用的集合写空数组。

knowledge_ref 为精确版本、路径、sha256 的知识 4.0.0 ArtifactRef。依据链来自知识中的 statement、term、rule 标识；模型不得创建新的制度断言。knowledge_basis 表示上游依据状态，不是 DSL 的业务批准。

## 类型与关系

Type：`id, name, kind, description, basis_ids, identity, fields, examples, counterexamples`。kind 为 ENTITY/ROLE/FACT/EVENT/OBSERVATION/EVIDENCE/DECISION/TASK。identity 至少一个本类型字段，每个键为必需、单值。角色额外提供单值、必需 Ref 的 bearer_field。

Field：`name, label, type, cardinality: {min, max}, description`。max=null 表示多值无上限。类型为 Text/Boolean/Integer/Decimal/Date/DateTime/Enum/Ref/IntervalSet；Enum 必须声明 values，Ref 必须声明 target。关系由 Ref 字段的方向、目标类型、基数表达，不重复另建关系表。

identity 声明不是缺证时生成虚拟身份的许可。输入记录中的未知值须保留未知。Decimal 用十进制数值运算；原始输入推荐十进制字符串，求值的 Decimal 结果按字符串输出以保精度。禁止 NaN/Infinity。

## 时间

Temporal：`id, type_id, start_field, end_field, end_status_field, basis_ids`。起止同为 Date 或同为 DateTime；起点必需、终点可空，状态 Enum 包含 OPEN/KNOWN/UNKNOWN。

区间为 `[start,end)`：OPEN 代表有依据确认尚未终止，UNKNOWN 代表无法确定终止，二者均可有空 end，但不可互换。KNOWN 必须 end>start。同日先后无法证明时不能假造精度。

## 规则表达式

Rule：`id, name, description, inputs, result, expression, on_unknown: PROPAGATE, basis_ids`。输入按 name 声明类型；结果声明类型。表达式四选一：

```yaml
expression:
  op: and
  args:
    - input: corrected
    - input: consistent
```

其他表达式：`{literal: {type: Integer, value: 25}}`、`{field: {of: {input: self}, name: state}}`。只有声明过的输入、字段、运算符可用；没有字符串代码、eval、跨规则调用。

| 运算符 | 参数 | 结果 |
| --- | --- | --- |
| and/or | 至少两个 Boolean | 三值 Boolean |
| not | 一个 Boolean | 三值 Boolean |
| eq/ne | 两个兼容单值 | Boolean 或 UNKNOWN |
| lt/lte/gt/gte | 数值或相同日期类型 | Boolean 或 UNKNOWN |
| add/multiply | 至少两个数值 | Decimal 或 UNKNOWN |
| current_interval_start | IntervalSet, Date, Boolean, Boolean | Date 或 UNKNOWN |

null 表示 UNKNOWN；不能把缺失变成 false 或 0。false AND unknown=false，true OR unknown=true，其余按三值逻辑。比较未知值仍为 UNKNOWN。

current_interval_start 的后两个参数为 history_complete、continuity_verified。任一不为 true 或任一区间终止未知，返回 UNKNOWN。有证据支持完整性与连续性后，才归并重叠/相接区间并取包含 as_of 的当前区间起点；真实空档保留。没有当前达标区间返回 UNKNOWN。输入区间为 `{start, end, end_status}`，此运算符只接受 Date。它不证明输入的历史完整性或实际法律生效。

## 状态与人工判断

StateMachine：`id, type_id, state_field, initial, transitions, basis_ids`。state_field 为单值 Enum；迁移：`id, event, from, to, guard, on_unknown: BLOCK, basis_ids`。guard 只读取 self 记录，必须为 Boolean。同一状态与事件不得出现两条路径；本版不推测优先级。求值只计算转换建议，不写数据库，不自动保存历史。

Judgment：`id, name, description, inputs, outputs, responsible_role, required_evidence, question_ids, issue_ids, on_missing: BLOCK, basis_ids`。这是显式人工裁定边界，没有自动求值。关联开放 MODEL_GAP；仅有人工裁定声明的问题不得计为 MODELED。

## 覆盖与确认

question_coverage 逐题列模型 ID、缺口 ID、MODELED/PARTIAL/DEFERRED 与原因。case_explanations 逐例保留知识预期及禁止结果，标 EXPLAINED/BLOCKED；解释不等于执行通过。upstream_issue_bindings 穷举上游 OPEN，含范围外及理由；未解决的上游问题对应本地开放缺口。

输入、DSL 和交接须绑定同一知识版本及问题范围。review.md、coverage.md 为确定性视图；合同检查比较其生成字节以发现单独修改。审阅意见另写 review-session-log.md，修订在 DSL 中落实。
