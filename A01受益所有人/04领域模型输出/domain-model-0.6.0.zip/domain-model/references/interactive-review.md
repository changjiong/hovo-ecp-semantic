# 模型评审与线下回路

review_mode 只管理模型的评审组织方式；knowledge_basis 管理模型采用的知识依据。这两个选择独立。

## 会话评审

IN_SESSION 时，先展示 review.md 的范围、概念与关系、判断步骤、案例、上游未决项和模型分歧。按问题逐项记录答复者、角色、时间、答复内容、影响的模型要素和案例。答复文件作为独立 ArtifactRef 保存，不回写已经确认的字节。

如果知识依据为 DRAFT，会话可评议模型，但模型仍保持 PENDING，不能以本轮讨论制造上游知识确认。知识依据为 CONFIRMED 时，仍应把模型本身的确认范围与上游知识确认分开记录。

## 线下评审

DEFERRED 时交付 model.yaml、待审 review.md、coverage.md、output.json 和原始反馈入口。业务人员只需按可读标题对范围、概念、条件、例外、案例、证据和未决项给出意见；不要求编辑 JSON 或内部 ID。

收回反馈后，先核对其绑定的版本、摘要和范围，再执行 REVISE：保存原反馈，列受影响问题、案例、概念和机制，生成新版本，并将受影响旧确认标为历史。新的范围重新进入会话或线下评审。

## 禁止替代

作者自查、自动检查、模型建议、会议纪要未答复、PENDING scope 和结构 PASS 都不是确认。DRAFT 可完成草案整理，不能正式交接；CONFIRMED 需要真实的外部 ConfirmationRecord，而不是生成器内联字段。

0.6.0 起，review.md/coverage.md 是 DSL 的生成视图。业务人员只提交原始反馈；整理者在新内容版本的 model.yaml 落实修改，再生成材料并校验。正式模型确认应绑定 output.json、model.yaml、review.md、coverage.md 的精确引用，不继承旧版本批准。平台消费者未支持本 DSL 时只可供模型评审，不宣称平台交接完成。
