# 平台无关领域资产合同 2.0.0

本技能的输入、输出和公共对象均随包提供；公共对象只管理资产身份、版本、来源、证据、案例、问题和审查状态。本包不加载其他技能目录。2.0.0 替代原1.0.0领域合同，不接受旧版作为新版成果，不自动迁移或填造缺项。

## 使用与模式

用户可提供文档、业务说明或其他工具成果。由技能形成机器可检查的交接文件，保留原文件、定位与含义；JSON 不是用户访谈的前置要求。

PRODUCE 创建模型草案；REVIEW 只审查 subjects 指定的对象；REVISE 依据明确变更请求更新指定成果。创建和修订必须声明 `review_mode`：`IN_SESSION` 要求知识确认记录，并在当前会话完成范围内的真实答复；`DEFERRED` 允许没有确认记录，但产物只能是待审草案，不能声称正式下游交接。REVIEW 无需已有业务确认，输出 content.subjects、assessment、limitations 与顶层 issues，不输出 confirmation，也不伪造一份完整基线来容纳审查发现。

## 文件、身份与状态

output.json 维护结构化成果，review.md 面向业务责任人呈现同一内容。稳定 artifact_id 与内部 ID 用于追踪，content_version 随变化，contract_version 固定本合同版本。引用使用完整 ArtifactRef，path 相对任务项目根目录，digest 是文件原始字节的 SHA-256；禁止路径越界、符号链接和凭据。

states 只记录 structure_checked 与 business_reviewed。前者证明实际结构与引用检查，后者记录业务内容审查。确认单独使用 confirmation 和外部 ConfirmationRecord，不继承任何平台编译、发布或运行状态。

未执行写 NOT_EXECUTED；已执行的 PASS、FAIL、ERROR 必须有实际证据。不适用必须说明理由。确认对象的摘要不能写入它自身；固定草案后计算摘要，外部确认记录引用该文件和真实答复。确认不会修改已经签认的文件，后续使用同时携带该成果与其独立确认记录。

## 引用与确认

SourceRef 定位来源主体、时间、版本和原文位置。Statement.source_ids 指向来源，Term/Rule.statement_ids 指向陈述，Case.question_ids 指向业务问题。模型 basis_ids 指向所绑定知识中的陈述、术语或规则；关系端点、属性归属和语义政策必须指向已声明的模型要素。

模型 content.knowledge_ref 必须同时登记在 input_refs，固定准确知识版本。question_scope_ids 是本模型承接的知识问题范围，必须与模型 confirmation.scope_ids 一致；知识与模型的新 ID 使用明确前缀避免冲突。案例预期与禁止结果逐字保留，业务解释另写，不用重述来隐藏规则变化。

`IN_SESSION` 的确认记录须包含真实责任人、角色、时间、scope_ids、完整 subjects 和答复文件。知识确认范围使用业务问题 ID；模型创建范围必须被知识确认范围覆盖。`DEFERRED` 的 confirmation 必须保持 `PENDING` 并说明未审范围及恢复入口。具体陈述或规则的 review_status 不抹去其 origin 或争议记录；声称已确认时还需对应 evidence 引用，审查者核对答复事项与原文是否匹配。作者或脚本不能替代责任人。

issues 记录问题、影响 ID、建议、责任和解决前行为。REVIEW 的 affects 可以指向被审资产 ID，并用 locator 指明原文位置。业务缺口与冲突不因检查工具返回 PASS 而消失。trace 两端必须落在本次资产、来源、模型或所引用知识的有效标识上，禁止用自由文本冒充引用。

## 业务完成与校验范围

关键问题审查正例、反例、边界与缺证，确实不适用写理由；未覆盖写明确缺口。阶段内校验能拒绝悬空引用、错误类型、重复或遗漏覆盖、基数冲突、部分循环及被改写的案例预期。它不能证明来源真实性、业务逻辑正确性、审查者身份或宿主上下文隔离。

本地入口为 scripts/validate_contract.py --check-schemas 和 validate input|output FILE --project-root ROOT。Registry 按本包 Schema 的 $id 离线解析，hovo.local 只是命名空间；不访问网络、不读取其他技能合同。

修改已确认业务内容时，先列影响，再产生新版本并重新确认受影响事项。旧证据保留为历史，不用于变化后的字节。公共合同的固定快照与工具摘要见 [sources.json](../references/sources.json)。
