# domain-model

形成与数据库、软件和平台无关的领域模型，解释业务对象及判断依据。Hovo 0.3.0，本地候选，资产合同2.0.0。

> 使用 domain-model，依据这份已确认知识基线定义业务概念、属性、关系、时间和判断机理。

> 使用 domain-model，先审查这份已有模型。缺少知识确认可以作为发现，不要替我生成或批准新模型。

## 输入与交付

创建需要已确认的知识及确认依据；审查只需要已有模型；修订需要原模型、变更请求和已确认知识。技能负责整理结构化引用，不要求用户预先填写 JSON。人工和其他工具提供的成果均可使用，按当前合同核对，不要求先执行其他技能。

创建或修订交付 output.json 与业务 review.md；审查交付定位明确的问题、建议、限制与审查报告。业务认可依赖真实确认记录。完整字段见 [输入](contracts/input.schema.json)、[输出](contracts/output.schema.json) 与 [合同说明](contracts/README.md)，完成条件见 [验收清单](references/acceptance.md)。

## 独立使用与检查

完整目录可放入宿主支持的 skills 目录单独调用。本包自带资料、合同与工具，不需要其他技能或平台服务。Python 3.10+ 依赖见 [requirements.txt](requirements.txt)。在本技能目录运行：

```bash
python3 -m pip install -r requirements.txt
python3 scripts/validate_contract.py --check-schemas
python3 scripts/validate_contract.py validate input /path/to/project/domain-model/input.json --project-root /path/to/project
python3 scripts/validate_contract.py validate output /path/to/project/domain-model/output.json --project-root /path/to/project
```

## 排查与证据

悬空引用应修正具体来源或概念 ID；覆盖遗漏应补内容或明确缺口；案例预期变化应退回知识责任人确认。旧合同1.0.0不能作为2.0.0成果直接使用，重新编制时保留原始材料与变化依据，不能自动填入确认。

本地检查证明结构与有限一致性，不证明来源真实、业务逻辑正确或专家认可。当前未执行真实模型生成评估、专家评审与宿主安装验证。旧 reports/standalone-checks.json 只证明0.2.0；本次记录见 [修订记录](reports/domain-revision.md)。资料快照见 [sources.json](references/sources.json)，权利与方法借鉴见 [来源说明](THIRD_PARTY_NOTICES.md)。
