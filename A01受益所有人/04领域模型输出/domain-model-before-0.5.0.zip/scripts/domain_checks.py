"""Business reference and coverage checks for platform-independent domain assets."""
from __future__ import annotations

from collections import Counter
from graphlib import CycleError, TopologicalSorter
from typing import Any

CASE_KINDS = {"POSITIVE", "NEGATIVE", "BOUNDARY", "MISSING_EVIDENCE"}


def objects(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from objects(child)
    elif isinstance(value, list):
        for child in value:
            yield from objects(child)


def index(items, key="id"):
    return {item[key]: item for item in items}


def check_content(payload: dict[str, Any], failures: list[dict[str, str]], knowledge=None):
    """Check declared references; business truth still needs domain review."""
    def fail(code, location, message):
        failures.append({"code": code, "location": location, "message": message})

    def refs(values, allowed, location):
        for value in values:
            if value not in allowed:
                fail("REFERENCE_UNDEFINED", location, f"未定义或类型不符的引用: {value}")

    def exact_coverage(values, expected, location):
        counts = Counter(values)
        for value in sorted(expected - counts.keys()):
            fail("COVERAGE_MISSING", location, f"未覆盖: {value}")
        for value, count in counts.items():
            if value not in expected or count != 1:
                fail("COVERAGE_INVALID", location, f"范围外或重复覆盖: {value}")

    def acyclic(graph, location):
        try:
            tuple(TopologicalSorter(graph).static_order())
        except CycleError as exc:
            fail("REFERENCE_CYCLE", location, f"循环依赖: {exc.args[1]}")

    content = payload["content"]
    issues = index(payload["issues"])
    evidence_ids = {item["evidence_id"] for item in payload["evidence"]}
    artifact_ids = {item["artifact_id"] for item in objects(payload) if "artifact_id" in item}
    local_ids = {item["id"] for item in objects(payload) if "id" in item}
    allowed = artifact_ids | local_ids | evidence_ids
    if payload["mode"] == "REVIEW":
        for subject in content["subjects"]:
            if subject not in payload["input_refs"]:
                fail("REVIEW_SUBJECT_UNBOUND", "content/subjects", "审查对象必须是精确输入引用")
    elif payload["stage"] == "domain-knowledge":
        sources = index(content["sources"], "source_id")
        statements = index(content["statements"])
        terms = index(content["terms"])
        questions = index(content["questions"])
        rules = index(content["rules"])
        cases = index(content["cases"])
        allowed |= sources.keys()
        for item in statements.values():
            refs(item["source_ids"], sources, item["id"] + "/source_ids")
            refs(item.get("supporting_statement_ids", []), statements, item["id"] + "/supporting_statement_ids")
        acyclic({key: value.get("supporting_statement_ids", []) for key, value in statements.items()}, "statements")
        for item in terms.values():
            refs(item["statement_ids"], statements, item["id"] + "/statement_ids")
        for item in rules.values():
            refs(item["statement_ids"], statements, item["id"] + "/statement_ids")
            refs(item["question_ids"], questions, item["id"] + "/question_ids")
        for item in (*statements.values(), *rules.values()):
            conflicts = {key: issue for key, issue in issues.items() if issue["kind"] == "CONFLICT"}
            refs(item["conflict_ids"], conflicts, item["id"] + "/conflict_ids")
            for conflict_id in item["conflict_ids"]:
                conflict = conflicts.get(conflict_id)
                if conflict and item["id"] not in conflict["affects"]:
                    fail("CONFLICT_BINDING_INVALID", item["id"], "冲突没有关联当前陈述或规则")
                if conflict and item["dispute_status"] == "RESOLVED" and conflict["status"] != "RESOLVED":
                    fail("CONFLICT_UNRESOLVED", item["id"], "冲突记录尚未解决")
        for item in cases.values():
            refs(item["question_ids"], questions, item["id"] + "/question_ids")
            refs(item["source_ids"], sources, item["id"] + "/source_ids")
        exact_coverage([row["question_id"] for row in content["case_coverage"]], set(questions), "case_coverage")
        for row in content["case_coverage"]:
            refs(row["case_ids"], cases, "case_coverage/case_ids")
            gaps = {key for key, item in issues.items() if item["kind"] == "KNOWLEDGE_GAP" and item["status"] == "OPEN" and row["question_id"] in item["affects"]}
            refs(row["gap_ids"], gaps, "case_coverage/gap_ids")
            linked = {key for key, item in cases.items() if row["question_id"] in item["question_ids"]}
            if set(row["case_ids"]) != linked:
                fail("CASE_COVERAGE_MISMATCH", row["question_id"], "案例目录与能力问题覆盖不一致")
            represented = {cases[key]["kind"] for key in row["case_ids"] if key in cases}
            excluded = [item["kind"] for item in row["not_applicable"]]
            if len(excluded) != len(set(excluded)) or represented.intersection(excluded):
                fail("CASE_APPLICABILITY_CONFLICT", row["question_id"], "同类案例同时声明覆盖、不适用或重复排除")
            if CASE_KINDS - represented - set(excluded) and not row["gap_ids"]:
                fail("CASE_KIND_MISSING", row["question_id"], "正例、反例、边界、缺证未完整覆盖且没有缺口")
        refs(payload["confirmation"]["scope_ids"], questions, "confirmation/scope_ids")
    elif payload["stage"] == "domain-model":
        if knowledge is None:
            fail("KNOWLEDGE_REQUIRED", "content/knowledge_ref", "模型输出必须绑定可核对的知识基线")
            return
        kc = knowledge["content"]
        statements, terms = index(kc["statements"]), index(kc["terms"])
        rules, questions, cases = index(kc["rules"]), index(kc["questions"]), index(kc["cases"])
        knowledge_ids = statements.keys() | terms.keys() | rules.keys() | questions.keys() | cases.keys()
        allowed |= knowledge_ids
        allowed |= {s["source_id"] for s in kc["sources"]}
        concepts = index(content["concepts"])
        attributes = index(content["attributes"])
        relationships = index(content["relationships"])
        mechanisms = index(content["mechanisms"])
        policies = {
            policy["id"]: policy
            for aspect in content["semantics"].values()
            for policy in aspect["policies"]
        }
        model_ids = concepts.keys() | attributes.keys() | relationships.keys() | mechanisms.keys() | policies.keys()
        core_ids = concepts.keys() | attributes.keys() | relationships.keys()
        for collision in sorted(model_ids & knowledge_ids):
            fail("ID_NAMESPACE_COLLISION", collision, "模型新标识不能与知识标识重复；请使用明确前缀")
        scope = set(content["question_scope_ids"])
        refs(scope, questions, "question_scope_ids")
        refs(scope, set(knowledge["confirmation"]["scope_ids"]), "knowledge/confirmation_scope")
        if set(payload["confirmation"]["scope_ids"]) != scope:
            fail("CONFIRMATION_SCOPE_MISMATCH", "confirmation/scope_ids", "模型确认范围必须与能力问题范围一致")
        if content["knowledge_ref"] not in payload["input_refs"]:
            fail("KNOWLEDGE_REF_UNBOUND", "content/knowledge_ref", "知识基线必须登记为精确输入引用")
        basis_ids = statements.keys() | terms.keys() | rules.keys()
        for item in (*concepts.values(), *attributes.values(), *relationships.values(), *policies.values()):
            refs(item["basis_ids"], basis_ids, item["id"] + "/basis_ids")
        for item in concepts.values():
            refs(item.get("parent_ids", []), concepts, item["id"] + "/parent_ids")
            if "role_bearer_id" in item:
                refs([item["role_bearer_id"]], concepts, item["id"] + "/role_bearer_id")
        acyclic({key: value.get("parent_ids", []) for key, value in concepts.items()}, "concepts/parent_ids")
        for item in attributes.values():
            refs([item["owner_id"]], concepts.keys() | relationships.keys(), item["id"] + "/owner_id")
        for item in relationships.values():
            refs([item["from_id"], item["to_id"]], concepts, item["id"] + "/endpoints")
        for item in objects(content):
            if set(item) == {"min", "max"} and item["max"] is not None and item["min"] > item["max"]:
                fail("CARDINALITY_INVALID", "content", "基数最小值超过最大值")
        for policy in policies.values():
            refs(policy["applies_to_ids"], core_ids, policy["id"] + "/applies_to_ids")
        for item in mechanisms.values():
            refs(item["rule_ids"], rules, item["id"] + "/rule_ids")
            refs(item["question_ids"], scope, item["id"] + "/question_ids")
            refs(item["input_ids"], core_ids, item["id"] + "/input_ids")
            refs(item["output_ids"], core_ids, item["id"] + "/output_ids")
            refs(item["policy_ids"], policies, item["id"] + "/policy_ids")
            available = set(item["input_ids"])
            produced = set()
            for step in item["steps"]:
                refs(step["input_ids"], core_ids, step["id"] + "/input_ids")
                refs(step["input_ids"], available, step["id"] + "/available_inputs")
                refs(step["output_ids"], core_ids, step["id"] + "/output_ids")
                refs(step["rule_ids"], set(item["rule_ids"]), step["id"] + "/rule_ids")
                if step["kind"] == "APPLY_RULE" and not step["rule_ids"]:
                    fail("STEP_RULE_REQUIRED", step["id"], "应用规则步骤必须引用具体业务规则")
                available.update(step["output_ids"])
                produced.update(step["output_ids"])
            refs(item["output_ids"], produced, item["id"] + "/produced_outputs")
        exact_coverage([row["question_id"] for row in content["question_coverage"]], scope, "question_coverage")
        for row in content["question_coverage"]:
            refs(row["model_ids"], model_ids, "question_coverage/model_ids")
            gaps = {key for key, item in issues.items() if item["kind"] == "MODEL_GAP" and item["status"] == "OPEN" and row["question_id"] in item["affects"]}
            refs(row["gap_ids"], gaps, "question_coverage/gap_ids")
            linked = {key for key, item in mechanisms.items() if row["question_id"] in item["question_ids"]}
            if linked and not linked.intersection(row["model_ids"]) and not row["gap_ids"]:
                fail("MECHANISM_COVERAGE_MISSING", row["question_id"], "能力问题没有关联对应判断机理")
        expected_cases = {key for key, item in cases.items() if scope.intersection(item["question_ids"])}
        exact_coverage([row["case_id"] for row in content["case_explanations"]], expected_cases, "case_explanations")
        for item in content["case_explanations"]:
            refs(item["model_ids"], model_ids, "case_explanations/model_ids")
            case = cases.get(item["case_id"])
            if case and (item["expected"] != case["expected"] or item["forbidden"] != case["forbidden"]):
                fail("CASE_EXPECTATION_CHANGED", item["case_id"], "模型不能改写知识基线的预期或禁止结果")
    for issue in issues.values():
        refs(issue["affects"], allowed, issue["id"] + "/affects")
    for item in payload["trace"]:
        refs([item["from_id"], item["to_id"]], allowed, "trace")
