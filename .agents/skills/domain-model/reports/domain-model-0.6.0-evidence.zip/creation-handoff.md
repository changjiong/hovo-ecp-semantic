# domain-model 0.6.0 本地交付

状态：candidate，scaffold 已实现，Production 是目标，尚未取得完整生产成熟度证据。用户指定 qiaomu-meta-skill 为唯一工程方法；Hovo 继续维护本技能。

交付重点是 model.yaml 作为唯一领域定义，配套 DSL 1.0.0、模型合同 4.0.0、安全 YAML 解析、类型与引用校验、有限规则求值、状态迁移和生成文档一致性检查。0.5.0 本地备份位于 /tmp/domain-model-before-060.zip；旧合同不保留兼容入口，现有业务模型不自动迁移。

## 参考技能与本次选择

- **设计优势**：借鉴 [mattpocock/domain-modeling](https://github.com/mattpocock/skills/blob/main/skills/engineering/domain-modeling/SKILL.md) 的具体反例和术语边界；拒绝把词汇表当本任务最终模型。领域类型附依据、正反例，代码实现不决定业务含义。
- **设计优势**：借鉴 [lai-gen-descriptor](https://github.com/eclipse-langium/langium-ai/blob/main/skills/lai-gen-descriptor/SKILL.md) 的单一声明生成、真实引用检查和有效示例；拒绝引入其 Langium 工具链。DSL 驱动审阅材料并检查漂移。
- **本次贡献，设计优势**：为既有知识合同增加可解析 DSL、未知值传播、确定性守卫、连续区间示例算子和人工裁定缺口。不是通用推理平台，也未执行真实客户判断。
- **待验证假设**：业务人员更易审阅、模型能更稳定地产生完整 DSL。没有用户研究或模型对照评估，不作效果优越性声明。

源码阅读、候选取舍、目录证据见 prior-art-research.md 与 prior-art-candidates.json。**已验证优势（有限实测）**：技能包结构检查通过；11 条关键词启发式触发用例通过，不代表真实模型服务路由。10 个 DSL CLI 输入的规则/迁移结果符合预期，7 类错误输入均被拦截；A01 精确知识引用、问题案例覆盖和生成文档一致性检查通过。修复过扁平运算符解析、区间数组值以及时间规范化问题，最后以整合后的文件生成并核验。其他有限实测证据见 validation.json、trigger-eval.json、output-eval.json 和 rejection-eval.json（以实际文件及状态为准，不存在即缺失）。Skill IR 见 skill-ir.json。

## 范围与缺失证据

A01 聚焦示例只建模形成日期、差异闭环的计算部分：2 个问题、5 个完整业务案例仍标部分/受阻，不代表原41题全部形式化。上游知识及原05成果未改写。合成订单示例只证明语法和布尔求值可用于另一领域，不能证明广泛迁移质量。

包检查的 README 警告采用固定英文/公开安装关键字启发式；本地候选包没有声称远程安装入口，中文使用说明和实际本地校验命令在 README。该类警告保留在报告，不通过添加虚构安装命令消除。

缺失：真实模型服务触发/生成评估、业务责任人验收、全量领域模型重生成、下游 ECP 消费适配与编译、干净宿主安装发现、跨平台运行、完整单元测试。启发式触发报告是关键词烟雾检查；静态 PASS 与示例运行不替代这些证据。没有发布或外部写操作。
